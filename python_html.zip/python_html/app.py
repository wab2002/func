from flask import Flask, render_template, request, redirect

app = Flask(__name__)

data_list = [
    {"username": "张尖峰", "password": "123221", "email": "131@qq.com", "telphone": "1414351", "gender": "男"},
    {"username": "张小妹", "password": "122131", "email": "121@qq.com", "telphone": "1412351", "gender": "女"}
]


@app.route('/login', methods=['GET', 'POST'])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    if request.method == 'POST' \
            and username == 'admin' \
            and password == '1':
        return redirect("/show")

    return render_template("login.html")


@app.route("/adduser", methods=['GET', 'POST'])
def adduser():
    if request.method == "GET":
        return render_template("adduser.html")
    username = request.form.get("username")
    password = request.form.get("password")
    email = request.form.get("email")
    telphone = request.form.get("telphone")
    gender = request.form.values()                           #获取不到性别的值
    data_list.append(
        {"username": username, "password": password, "email": email, "telphone": telphone, "grnder": gender})
    return render_template("login.html", )


@app.route("/show")
def show():
    return render_template("show.html", data_list=data_list)


@app.route("/delete")
def delete():
    username = request.args.get("username")
    print(username)
    print(request.method)
    for data in data_list:
        if data["username"] == username:
            data_list.remove(data)

    return redirect("/show")


# 获取用户信息错误
@app.route("/change", methods=["GET", "POST"])
def change():
    username = request.args.get("username")
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        email = request.form.get("email")
        telphone = request.form.get("telphone")
        gender = request.form.get("gender")

        for data in data_list:
            if data["username"] == username:
                data["password"] = password
                data["email"] = email
                data["telphone"] = telphone
                data["gender"] = gender
        return redirect("/show")
    for data in data_list:
        if data["username"] == username:
            return render_template("change.html", data=data)

    return render_template("change.html", data=data_list)


if __name__ == '__main__':
    app.run()
